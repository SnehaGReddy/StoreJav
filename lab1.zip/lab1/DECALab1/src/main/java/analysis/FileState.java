package analysis;

public enum FileState {
	Init, Open, Close
}
